from ultralytics import YOLO
import cv2
import numpy as np
import time

# Variables a ajustar
escala = 1
umbral_confianza_det = 0.2
umbral_confianza_ocr = 0.45
y_thresh_valor = 0.5

# Se utiliza el modelo entrenado
modeloDET = YOLO('modelos/DetMatriculasV1.pt')
modeloOCR = YOLO('modelos/OCRV1.pt')

# Apertura de imagen
# path = 'imagenesTEST/Coche5.jpg'
# path = 'imagenesTEST/Camion.jpg'
# path = 'imagenesTEST/Furgoneta.jpg'
# path = 'imagenesTEST/MatriculaCerca.jpg'
path = 'imagenesTEST/OsoCanada.jpg'

imagen = cv2.imread(path)

# Se aplica el modelo de la red neuronal
resultadosDET = modeloDET.predict(imagen, conf=umbral_confianza_det, max_det=1)[0]

# Se dibuja la bounding box sobre la imagen original, para ver lo que se va a recortar
boundingboxDET = resultadosDET.plot(line_width=1)

# Se extraen de los resultados las coordenadas de la boundingbox de la detección,
# en formato XY,XY (esquinas de la bounding box)
XYXYDET = resultadosDET.boxes.xyxy
if XYXYDET.numel():
    X1bb = int(XYXYDET[0, 0].item())
    Y1bb = int(XYXYDET[0, 1].item())
    X2bb = int(XYXYDET[0, 2].item())
    Y2bb = int(XYXYDET[0, 3].item())

    # Se crea una máscara vacía donde se cambia a negro todos los pixeles menos los de la boundingbox,
    # para ver con mas claridad la imagen
    mascara_matricula = np.zeros(resultadosDET.orig_img.shape[:2], np.uint8)
    mascara_matricula[Y1bb:Y2bb, X1bb:X2bb] = 255
    masked_imagen = cv2.bitwise_and(resultadosDET.orig_img, resultadosDET.orig_img, mask=mascara_matricula)

    # Se recortan el resto de pixeles
    matricula_recortada = resultadosDET.orig_img[Y1bb:Y2bb, X1bb:X2bb]

    # Se lee la imagen y se escala a un tamaño visible
    w, h = matricula_recortada.shape[0], matricula_recortada.shape[1]
    w, h = w*escala, h*escala
    matricula_escalada = cv2.resize(matricula_recortada, [h, w], cv2.INTER_CUBIC)

    # Se aplica el modelo de la red neuronal
    resultadosOCR = modeloOCR.predict(matricula_escalada, conf=umbral_confianza_ocr, max_det=12)[0]

    # Se dibuja la bounding box sobre la imagen original
    boundingboxOCR = resultadosOCR.plot(line_width=1)

    # Se determina el diccionario de clases, los indices del diccionario y las coordenadas
    # de las bounding boxes
    names = resultadosOCR.names
    clases = resultadosOCR.boxes.cls
    XYXYOCR = resultadosOCR.boxes.xyxy

    # Se crea una lista con las coordX, coordY y Clases de cada detección.
    XYC = []
    for i in range(len(clases)):
        XYC.append([int((XYXYOCR[i][2]+XYXYOCR[i][0])/2), int((XYXYOCR[i][3]+XYXYOCR[i][1])/2), int(clases[i])])

    # Se ordena la lista
    XYC.sort(key=lambda x: x[1])

    # Se determina el número de filas de la matrícula, y se crean dos listas con el contenido de cada fila
    fila1, fila2 = [], []
    ythreshold = XYC[0][1]+(y_thresh_valor*XYC[0][1])
    print('ythreshold: ', ythreshold)
    for i in range(len(clases)):
        if (XYC[i][1]) <= ythreshold:
            fila1.append(XYC[i])
        else:
            fila2.append(XYC[i])

    # Se ordenan las filas de izquierda a derecha
    fila1.sort()
    fila2.sort()

    # Se concatenan las filas detectadas y se extrae el valor final de las clases de la matricula
    filas_concatenadas = fila1 + fila2

    clases_concatenadas = []
    for i in range(len(filas_concatenadas)):
        clases_concatenadas.append(filas_concatenadas[i][2])

    # Se traduce el valor de las clases a la matrícula final
    Matricula_entrada = ""
    for i in range(len(clases_concatenadas)):
        Matricula_entrada = Matricula_entrada + names[clases_concatenadas[i]]

    print(' ')
    print('Matrícula: ', Matricula_entrada)
    print(' ')

# Se muestran los resultados
cv2.imshow('Detecciones', boundingboxDET)
cv2.waitKey(0)
cv2.imshow('Detecciones', masked_imagen)
cv2.waitKey(0)
cv2.imshow('Detecciones', matricula_escalada)
cv2.waitKey(0)
cv2.imshow('Detecciones', boundingboxOCR)
cv2.waitKey(0)
