import customtkinter as ctk
import cv2
from PIL import Image, ImageTk
import numpy as np
from ultralytics import YOLO
import time
from datetime import datetime
import json

#######################################
# VARIABLES #
#######################################
# Globales
global Matricula_entrada
#######################################
umbral_confianza_det = 0.2
umbral_confianza_ocr = 0.5
algoritmoOCR = 1  # 1: 1 linea, 2: 2 lineas
y_thresh_valor = 0.5  # Para el algoritmo de dos lineas
#######################################
# Inicialización de variables
Contador_Matricula_Anterior_entrada = 0
Matricula_Anterior_entrada = ""

matricula_reciente_entrada = ""
matricula_reciente_salida = ""
decision_entrada_pendiente = 0
#######################################


def cv2topil(imagenaconvetir):
    imagen_pil = cv2.cvtColor(imagenaconvetir, cv2.COLOR_BGR2RGB)
    imagen_pil = Image.fromarray(imagen_pil)
    return imagen_pil


def app():
    # Código de la app
    global ventana
    global imagen_entrada
    global imagen_salida
    ventana = ctk.CTk()
    ventana.title("Prueba ANPR")
    ventana.geometry("1300x670")  # Imagen dividida en dos verticalmente: 300+70+300
    ventana.minsize(1300, 670)
    ventana.maxsize(1300, 670)
    ctk.set_appearance_mode("Light")
    ctk.set_default_color_theme("dark-blue")

    # Se crean los cuadros, "frame"
    cuadro_entrada = ctk.CTkFrame(master=ventana, width=895, height=305, border_width=2)
    cuadro_salida = ctk.CTkFrame(master=ventana, width=895, height=305, border_width=2)
    cuadro_paramentrada = ctk.CTkFrame(master=cuadro_entrada, width=404, height=295, border_width=2)
    cuadro_paramsalida = ctk.CTkFrame(master=cuadro_salida, width=404, height=295, border_width=2)
    cuadro_registro = ctk.CTkFrame(master=ventana, width=300, height=600, border_width=2)

    # Se lee una imagen de ejemplo
    cargando = cv2.imread("imagenes_app/loading.jpg")
    imagen_pil = cv2topil(cargando)
    imagen_entrada_tk = ctk.CTkImage(imagen_pil, size=(480, 270))

    imagen_entrada = ctk.CTkLabel(cuadro_entrada, text=' ', image=imagen_entrada_tk)
    imagen_salida = ctk.CTkLabel(cuadro_salida, text=' ', image=imagen_entrada_tk)

    # Labels de texto
    label_entrada = ctk.CTkLabel(cuadro_entrada, text="Cámara de acceso: entrada",
                                 font=("ARIAL", 20), fg_color="transparent")
    label_salida = ctk.CTkLabel(cuadro_salida, text="Cámara de acceso: salida: ",
                                font=("ARIAL", 20), fg_color="transparent")

    # Se colocan los widgets
    # Cam entrada
    cuadro_entrada.place(x=20, y=5)
    label_entrada.place(x=10, y=4)
    imagen_entrada.place(x=1, y=33)
    cuadro_paramentrada.place(x=486, y=5)
    # cuadro_paramentrada.place(x=515, y=35)
    # Cam salida
    cuadro_salida.place(x=20, y=335)
    label_salida.place(x=10, y=4)
    imagen_salida.place(x=1, y=33)
    cuadro_paramsalida.place(x=486, y=5)
    # cuadro_paramsalida.place(x=515, y=365)
    # Registro
    cuadro_registro.place(x=930, y=30)

    ventana.after(1500, anpr)

    ventana.mainloop()


def anpr():
    def recortar_mat(resultados):
        # Se extraen de los resultados las coordenadas de la boundingbox de la detección,
        # en formato XY,XY (esquinas de la bounding box)
        XYXYDET = resultados.boxes.xyxy
        if XYXYDET.numel():
            X1bb = int(XYXYDET[0, 0].item())
            Y1bb = int(XYXYDET[0, 1].item())
            X2bb = int(XYXYDET[0, 2].item())
            Y2bb = int(XYXYDET[0, 3].item())

            # Se crea una máscara vacía donde se cambia a negro todos los pixeles menos los de la boundingbox,
            # para ver con mas claridad la imagen
            mascara_matricula = np.zeros(resultados.orig_img.shape[:2], np.uint8)
            mascara_matricula[Y1bb:Y2bb, X1bb:X2bb] = 255

            # Se recortan el resto de pixeles
            return resultadosDET.orig_img[Y1bb:Y2bb, X1bb:X2bb]

    def leer_mat(resultados):
        ####################################
        # Versión del algoritmo: una linea #
        ####################################

        # Se determina el diccionario de clases, los indices del diccionario y las coordenadas
        # de las bounding boxes
        names = resultados.names
        clases = resultados.boxes.cls
        XYXYOCR = resultados.boxes.xyxy

        # Se crea una lista con las coordX, coordY y Clases de cada detección.
        XYC = []
        for i in range(len(clases)):
            XYC.append([int((XYXYOCR[i][2] + XYXYOCR[i][0]) / 2), int((XYXYOCR[i][3] + XYXYOCR[i][1]) / 2),
                        int(clases[i])])

        if algoritmoOCR == 1:
            # Se ordena la lista, de izquierda a derecha
            XYC.sort()

            clases_concatenadas = []
            for i in range(len(XYC)):
                clases_concatenadas.append(XYC[i][2])

        else:
            # Se ordena la lista
            XYC.sort(key=lambda x: x[1])

            # Se determina el número de filas de la matrícula, y se crean dos listas con el contenido de cada fila
            fila1, fila2 = [], []
            ythreshold = XYC[0][1] + (y_thresh_valor * XYC[0][1])
            print('ythreshold: ', ythreshold)
            for i in range(len(clases)):
                if (XYC[i][1]) <= ythreshold:
                    fila1.append(XYC[i])
                else:
                    fila2.append(XYC[i])

            # Se ordenan las filas de izquierda a derecha
            fila1.sort()
            fila2.sort()

            # Se concatenan las filas detectadas y se extrae el valor final de las clases de la matricula
            filas_concatenadas = fila1 + fila2
            # print('filas concatenadas: ', filas_concatenadas)

            clases_concatenadas = []
            for i in range(len(filas_concatenadas)):
                clases_concatenadas.append(filas_concatenadas[i][2])

        # Se traduce el valor de las clases a la matrícula final
        Matricula_func = ""
        for i in range(len(clases_concatenadas)):
            Matricula_func = Matricula_func + names[clases_concatenadas[i]]

        if 5 < len(Matricula_func) < 10:
            return Matricula_func
        else:
            return 0

    def leerregistroaccesos():
        registro_func = open("RegistroAccesos.txt", "r")
        registrotexto_func = registro_func.read()
        if registrotexto_func != "":
            registrojson_func = json.loads(registrotexto_func)
            registro_func.close()
            return registrojson_func
        else:
            registro_vacio = []
            return registro_vacio

    def escribirregistroaccesos(registro):
        global matricula_reciente_entrada
        registro_func = open("RegistroAccesos.txt", "w")
        registronuevo_json = json.dumps(registro)
        registro_func.write(registronuevo_json)
        registro_func.close()
        matricula_reciente_entrada = Matricula

    def registrarentrada(matricula_func):
        registro = leerregistroaccesos()
        ahora = datetime.now()
        ahora_str = ahora.strftime("%m/%d/%Y %H:%M:%S")
        estructura_mat = [matricula_func, ahora_str]
        registro.append(estructura_mat)
        escribirregistroaccesos(registro)

    def activar_pregunta_entrada():
        print("Dejar pasar a vehiculo: SI o NO")

    global Matricula_entrada
    global Matricula_Anterior_entrada
    global Contador_Matricula_Anterior_entrada
    global matricula_reciente_entrada
    global decision_entrada_pendiente

    # Se obtiene el fotograma actual del video
    ret, fotograma = video.read()

    # Se comprueba si se ha leido correctamente el fotograma
    if ret:
        if decision_entrada_pendiente == 0:
            # Se aplica el modelo de la red neuronal
            resultadosDET = modeloDET.predict(fotograma, conf=umbral_confianza_det, max_det=1)[0]

            # Se comprueba si existe una detección de matricula
            if resultadosDET.boxes.xyxy.numel():
                # Se llama a la funcion recortar_mat() para recortar el resto de pixeles
                matricula_recortada = recortar_mat(resultadosDET)

                # Se aplica el modelo de la red neuronal
                resultadosOCR = modeloOCR.predict(matricula_recortada, conf=umbral_confianza_ocr, max_det=9)[0]

                # Se comprueba si existe al menos una detección de caracter
                if resultadosOCR.boxes.xyxy.numel():
                    # Se llama a la función que lee la matrícula
                    Matricula = leer_mat(resultadosOCR)

                    archivo_permitidas = open("Permitidas.txt", "r")
                    permitidas_list = archivo_permitidas.read().split('\n')
                    archivo_permitidas.close()

                    if Matricula != matricula_reciente_entrada:
                        if Matricula in permitidas_list:
                            print(' ')
                            print('Matrícula Permitida: ', Matricula)
                            print(' ')
                            # Se escribe en el registro la entrada permitida
                            registrarentrada(Matricula)

                        else:
                            # Si la matricula es la misma, se aumenta el contador
                            if Matricula_Anterior == Matricula and Contador_Matricula_Anterior < 3 and Matricula != 0:
                                Contador_Matricula_Anterior = Contador_Matricula_Anterior + 1

                            # Si la matrícula no es la misma que la anterior
                            elif Matricula_Anterior != Matricula:
                                Contador_Matricula_Anterior = 0

                            # Si la matrícula es la misma que la anterior y el contador es correcto
                            # se confirma que la matricula leida es desconocida
                            elif Matricula_Anterior == Matricula and Contador_Matricula_Anterior >= 3:
                                print(' ')
                                print('Matrícula Desconocida: ', Matricula)
                                print(' ')
                                activar_pregunta_entrada()
                                decision_entrada_pendiente = 1

                        # Matricula anterior
                        Matricula_Anterior = Matricula

                    # Se dibuja la bounding box sobre las imagenes
                    boundingboxDET = resultadosDET.plot(line_width=1)

                    # Se convierte la imagen CV2 a PIL
                    imagen_pil_func = cv2topil(boundingboxDET)

                    # Se muestra por pantalla la imagen
                    imagen_label_2 = ctk.CTkImage(imagen_pil_func, size=(480, 270))
                    imagen_entrada.configure(image=imagen_label_2)
                    imagen_entrada.image = imagen_label_2

            else:
                imagen_pil_2 = cv2topil(fotograma)
                imagen_label_2 = ctk.CTkImage(imagen_pil_2, size=(480, 270))
                imagen_entrada.configure(image=imagen_label_2)
                imagen_entrada.image = imagen_label_2

    ventana.after(33, anpr)


# Se cargan los modelos a emplear
modeloDET = YOLO('modelos/DetMatriculasV1.pt')
modeloOCR = YOLO('modelos/OCRV1.pt')

# Apertura de video
path = 'imagenesTEST/VideoBarrera.mp4'
video = cv2.VideoCapture(path)

# Se inicializan las globales

# Lanzamiento del programa
app()
